public class ProjectClassTest{
    public static void main(String[] args){
        ProjectClass np = new ProjectClass("Anton");

        np.elevatorPitch("Anton", "He likes to code");
    }
}